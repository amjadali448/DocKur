
export const getImportImgSuccess = "getImportImgSuccess";
export const getImportImgFail = "getImportImgFail";

export const getNetworkDataSuccess = "getNetworkDataSuccess";
export const getNetworkDataFail = "getNetworkDataFail";

export const getCreateNetworSuccess = "getCreateNetworSuccess";
export const getCreateNetworFail = "getCreateNetworFail";

export const getContainerListSuccess = "getContainerListSuccess";
export const getContainerListFail = "getContainerListFail";

export const getListofImagesSuccess = "getListofImagesSuccess";
export const getListofImagesFail = "getListofImagesFail";


export const getStartSuccess = "getStartSuccess";
export const getStartFail = "getStartFail";
export const getStopSuccess = "getStopSuccess";
export const getStopFail = "getStopFail";
export const getDeleteSuccess = "getDeleteSuccess";
export const getDeleteFail = "getDeleteFail";


// Create object  to get payload  


export const getBillingSuccess = "getBillingSuccess";
export const getBillingFail = "getBillingFail";
